 let etapa = 0;
 let historias = [
   
   

  "João planta milho em sua fazenda.",
  "A colheita foi feita com a ajuda de tratores modernos.",
  "O milho é transportado para a cidade.",
  "Chegando à feira, é vendido para os consumidores urbanos.",
  "A cidade é um polo para o campo, oferecendo acesso a mercados consumidores, onde os produtos agrícolas podem ser vendidos e distribuídos em larga escala"
  ]
 
 function setup() {
  createCanvas(600, 300);
  textAlign(CENTER, CENTER);
  textSize(20);
 }
 function draw() {
  background(245);
  text(historias[etapa], width / 2, height / 2);
  fill(200);
   
  rect(100, 250, 100, 30);
  rect(400, 250, 100, 30);
  fill(0);
  textSize(14);
  text("Voltar", 150, 265);
  text("Avançar", 450, 265);
 }
 function mousePressed() {
  if (mouseX > 100 && mouseX < 200 && mouseY > 250 && mouseY < 280 && etapa > 0) {
    etapa--;
  }
  if (mouseX > 400 && mouseX < 500 && mouseY > 250 && mouseY < 280 && etapa <
 historias.length - 1) {
    etapa++;
  }
 }
